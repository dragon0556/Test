package com.hd.test.service;

import java.util.List;
import java.util.Map;

public interface CacheService<String , V> {
    public String insertData(Map<String, Map<String, V>> data);
    public Map<String, V> getValue(String key);
    public List<String> getFilteredValue(String attribute, V value);
    public String deleteKey(String key);
}
