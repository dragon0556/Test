package com.hd.test.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CacheServiceImpl<String, V> implements CacheService<String, V>{
    private  final String SUCCESS_INSERT = (String) "Succefully Inserted the data";
    private  final String FAILED_INSERT = (String) "Data Insertion failed";
    private volatile Map<String, Map<String, V>> cacheMap = new HashMap<>();
    private Map<String, Class> typeMap = new HashMap<>();
    String result = SUCCESS_INSERT;
    boolean res = true;
    List<String> filteredKey;

    /*
    {
  "delhi": {
    "lat": 10,
     "long": 20
  },
     */
    @Override
    public String insertData(Map<String, Map<String, V>> data) {
        if(data == null || data.size() == 0){
            return FAILED_INSERT;
        }


        data.entrySet().stream().forEach(entry -> {
            String key = entry.getKey();
            Map<String, V> cacheValue = data.get(key);
            Map<String, V> existingValue = cacheMap.get(key);
            if(existingValue != null){
                if(!updateMap(key, cacheValue,existingValue)){
                    result = FAILED_INSERT;
                }
            }
            else {
                if(!insertDataToMap(key, cacheValue)){
                    result = FAILED_INSERT;
                }
            }

        });
        return result;
    }

    private boolean insertDataToMap(String key, Map<String, V> cacheValue) {
        res = true;
        cacheValue.entrySet().stream().forEach(entry ->{
            String valKey = entry.getKey();
            Class attributeVal = entry.getValue().getClass();
            Class oldAttr = typeMap.get(valKey);
            if(oldAttr != null){
                if(oldAttr !=  attributeVal){
                    res = false;
                }

            }
            else {
                typeMap.put(valKey, attributeVal);
            }
        });

        if(res){
            cacheMap.put(key, cacheValue);
        }

        return res;
    }

    private boolean updateMap(String key, Map<String, V> cacheValue, Map<String, V> existingValue) {
        res = true;
        cacheValue.entrySet().stream().forEach(entry ->{
            String valKey = entry.getKey();
            Class attributeVal = entry.getValue().getClass();
            Class oldAttr = typeMap.get(valKey);
            if(oldAttr != null){
                if(oldAttr !=  attributeVal){
                    res = false;
                }


            }
            else {
                typeMap.put(valKey, attributeVal);
            }
            if(res){
                existingValue.put(valKey, entry.getValue());
            }
        });
        if(res){
            cacheMap.put(key, existingValue);
        }
        return res;
    }

    @Override
    public Map<String, V> getValue(String key) {
        return cacheMap.get(key);
    }

    @Override
    public List<String> getFilteredValue(String attribute, V value) {
        filteredKey = new ArrayList<>();
        cacheMap.entrySet().stream().forEach(entry -> {
            String key = entry.getKey();
            Map<String, V> valMap = entry.getValue();
            valMap.entrySet().stream().forEach(val ->{
                if(attribute.equals(valMap.get(val.getKey())) && value.equals(val.getValue())){
                    filteredKey.add(key);

                }
            });
        });
        return filteredKey;
    }

    @Override
    public String deleteKey(String key) {
        if(cacheMap.get(key) != null){
            cacheMap.remove(key);
            return (String) "Successfully Deleted";
        }
        return (String) "Key is not available";
    }
}
