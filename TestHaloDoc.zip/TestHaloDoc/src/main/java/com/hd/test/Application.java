package com.hd.test;

import com.hd.test.service.CacheService;
import com.hd.test.service.CacheServiceImpl;

import java.util.HashMap;
import java.util.Map;

public class Application {
    public static void main(String[] args) {
        System.out.println("Halo Doc");

        CacheService cacheService = new CacheServiceImpl();

        Map<String, Map<String, Map<String, Integer>>> xxx = new HashMap<>();

        Map<String, Map<String, Integer>> map = new HashMap<>();
        Map<String, Integer> valMap = new HashMap<>();
        valMap.put("lat", 10);
        valMap.put("long", 20);
        //valMap.put("capital", "abc");
        map.put("Delhi", valMap);

//
        cacheService.insertData(map);
        Map<String, Map<String, String>> map1 = new HashMap<>();
        Map<String, String> valMap1 = new HashMap<>();
        valMap1.put("lat", "10");
        //valMap.put("capital", "abc");
        map1.put("Jakarta", valMap1);
        cacheService.insertData(map1);

        System.out.println(map);
    }
}
