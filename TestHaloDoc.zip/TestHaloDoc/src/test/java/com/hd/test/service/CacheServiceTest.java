package com.hd.test.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.HashMap;
import java.util.Map;

public class CacheServiceTest {
    String SUCCESS_INSERT = "Succefully Inserted the data";
    String FAILED_INSERT = "Data Insertion failed";
    CacheService cacheService = new CacheServiceImpl();

    @Test
    public void testInsertDataSuccess(){


        Map<String, Map<String, Integer>> map = new HashMap<>();
        Map<String, Integer> valMap = new HashMap<>();
        valMap.put("lat", 10);
        valMap.put("long", 20);
        //valMap.put("capital", "abc");
        map.put("Delhi", valMap);

        String str = (String) cacheService.insertData(map);

        Assert.assertEquals(str, SUCCESS_INSERT);
    }

    @Test
    public void testInsertDataFailed(){

        Map<String, Map<String, Integer>> map = new HashMap<>();
        Map<String, Integer> valMap = new HashMap<>();
        valMap.put("lat", 10);
        valMap.put("long", 20);
        //valMap.put("capital", "abc");
        map.put("Delhi", valMap);

        cacheService.insertData(map);
        Map<String, Map<String, String>> map1 = new HashMap<>();
        Map<String, String> valMap1 = new HashMap<>();
        valMap1.put("lat", "10");
        //valMap.put("capital", "abc");
        map1.put("Jakarta", valMap1);
        String str = (String) cacheService.insertData(map1);

        Assert.assertEquals(str, FAILED_INSERT);
    }
}
